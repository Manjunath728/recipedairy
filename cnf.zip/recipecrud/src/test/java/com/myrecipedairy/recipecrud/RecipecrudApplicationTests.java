package com.myrecipedairy.recipecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipecrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
